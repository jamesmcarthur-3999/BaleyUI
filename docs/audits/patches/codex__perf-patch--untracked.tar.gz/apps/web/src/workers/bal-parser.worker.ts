import { parseBalCode } from '@/lib/baleybot/generator';
import { balToVisualFromParsed } from '@/lib/baleybot/visual/bal-to-nodes';
import type { ParsedEntities } from '@/lib/baleybot/visual/types';
import type { BalToVisualResult } from '@/lib/baleybot/visual/bal-to-nodes';

type ParseRequest = {
  id: number;
  balCode: string;
};

type ParseResponse =
  | {
      id: number;
      ok: true;
      parsed: ParsedEntities;
      graphResult: BalToVisualResult;
    }
  | {
      id: number;
      ok: false;
      error: string;
    };

const ctx: DedicatedWorkerGlobalScope = self as DedicatedWorkerGlobalScope;

ctx.onmessage = (event: MessageEvent<ParseRequest>) => {
  const { id, balCode } = event.data;

  try {
    const parsed = parseBalCode(balCode);
    const graphResult = balToVisualFromParsed(balCode, parsed);

    const response: ParseResponse = {
      id,
      ok: true,
      parsed,
      graphResult,
    };

    ctx.postMessage(response);
  } catch (error) {
    const response: ParseResponse = {
      id,
      ok: false,
      error: error instanceof Error ? error.message : String(error),
    };

    ctx.postMessage(response);
  }
};

export {};
