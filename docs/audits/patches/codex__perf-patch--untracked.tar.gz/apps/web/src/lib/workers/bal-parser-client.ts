import type { BalToVisualResult } from '@/lib/baleybot/visual/bal-to-nodes';
import type { ParsedEntities } from '@/lib/baleybot/visual/types';

type ParseResponse =
  | {
      id: number;
      ok: true;
      parsed: ParsedEntities;
      graphResult: BalToVisualResult;
    }
  | {
      id: number;
      ok: false;
      error: string;
    };

export interface BalParserResult {
  parsed: ParsedEntities;
  graphResult: BalToVisualResult;
}

export interface BalParserClient {
  parse: (balCode: string) => Promise<BalParserResult>;
  terminate: () => void;
}

export function createBalParserClient(): BalParserClient | null {
  if (typeof window === 'undefined' || typeof Worker === 'undefined') {
    return null;
  }

  let worker: Worker;
  try {
    worker = new Worker(new URL('../../workers/bal-parser.worker.ts', import.meta.url), {
      type: 'module',
    });
  } catch {
    return null;
  }

  let nextId = 0;
  const pending = new Map<number, { resolve: (result: BalParserResult) => void; reject: (error: Error) => void }>();

  worker.onmessage = (event: MessageEvent<ParseResponse>) => {
    const message = event.data;
    const entry = pending.get(message.id);
    if (!entry) return;

    pending.delete(message.id);

    if (message.ok) {
      entry.resolve({ parsed: message.parsed, graphResult: message.graphResult });
    } else {
      entry.reject(new Error(message.error));
    }
  };

  worker.onerror = (error) => {
    pending.forEach(({ reject }) => reject(error instanceof Error ? error : new Error(String(error))));
    pending.clear();
  };

  return {
    parse: (balCode: string) =>
      new Promise<BalParserResult>((resolve, reject) => {
        const id = nextId++;
        pending.set(id, { resolve, reject });
        worker.postMessage({ id, balCode });
      }),
    terminate: () => {
      pending.clear();
      worker.terminate();
    },
  };
}
