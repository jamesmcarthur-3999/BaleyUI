'use client';

import { useMemo, useState } from 'react';
import { VisualEditor } from '@/components/visual-editor/VisualEditor';
import { BalCodeEditor } from '@/components/baleybot';

function makeBalCode(entities: number): string {
  const blocks: string[] = [];
  for (let i = 0; i < entities; i++) {
    blocks.push(`entity_${i} {\n  \"goal\": \"Analyze data chunk ${i}\",\n  \"model\": \"openai:gpt-4o-mini\",\n  \"tools\": [\"web_search\", \"store_memory\"],\n  \"output\": {\"result_${i}\": \"string\"}\n}`);
  }
  blocks.push('chain {');
  for (let i = 0; i < entities; i++) {
    blocks.push(`  entity_${i}`);
  }
  blocks.push('}');
  return blocks.join('\n\n');
}

export default function PerfLabPage() {
  const initial = useMemo(() => makeBalCode(200), []);
  const [balCode, setBalCode] = useState(initial);

  return (
    <div className="min-h-screen bg-gradient-hero p-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <h1 className="text-2xl font-semibold">Perf Lab</h1>
        <p className="text-sm text-muted-foreground">
          This page mounts VisualEditor and BalCodeEditor with a large BAL graph to stress
          parsing and rendering.
        </p>
        <div className="rounded-xl border bg-background p-4">
          <label className="block text-sm font-medium mb-2">Plain BAL textarea (easy to script)</label>
          <textarea
            value={balCode}
            onChange={(e) => setBalCode(e.target.value)}
            className="w-full h-40 rounded-lg border p-3 font-mono text-xs"
          />
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="h-[70vh] rounded-xl border bg-background">
            <VisualEditor balCode={balCode} onChange={setBalCode} />
          </div>
          <div className="h-[70vh] rounded-xl border bg-background p-2">
            <BalCodeEditor value={balCode} onChange={setBalCode} height="100%" />
          </div>
        </div>
      </div>
    </div>
  );
}
